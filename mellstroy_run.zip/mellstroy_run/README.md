# Меллстрой побег от фога (Godot 4.3+, Android)

Package name: `com.Damir4ik.mellstroyrun` · портрет 9:16 · рендерер GL Compatibility.

## Запуск
1. Откройте папку проекта в Godot 4.3 или новее (первый запуск импортирует ассеты).
2. F5 — играть. На ПК: ← → смена полосы, ↑/Space прыжок, ↓ подкат. На телефоне: свайпы.

## Сборка APK
1. Установите JDK 17 и Android SDK, укажите пути: Editor → Editor Settings → Export → Android.
2. Editor → Manage Export Templates → установите шаблоны своей версии Godot.
3. Project → Export → Android (пресет уже настроен: пакет, имя, иконки, arm64-v8a) → Export Project.
   Командой: `godot --headless --import` и затем
   `godot --headless --export-debug "Android" build/mellstroy_run.apk`
4. Для релиза: в пресете включите Gradle Build (для AAB) и укажите release keystore.

Ориентация: Project Settings → Display → Window → Handheld → Orientation = Portrait
(Android-экспорт берёт значение отсюда — горизонтальный режим запрещён).

## Что где
- `scripts/main.gd` — вся игра (мир, препятствия, игрок, костюмы, UI). Настройки сверху файла.
- `assets/sprites` — персонажи без зелёного фона; `costume*_sheet.png` — кадры костюмов (12 к/с).
- `assets/audio` — музыка, звуки костюмов (из ваших mp4), звук подбора.

Поток игры: костюм №1 (со своим звуком) → Меллстрой + музыка → столкновение →
музыка стоп, костюм №2 (со своим звуком) → GAME OVER, «Играть снова» / «Выйти».
